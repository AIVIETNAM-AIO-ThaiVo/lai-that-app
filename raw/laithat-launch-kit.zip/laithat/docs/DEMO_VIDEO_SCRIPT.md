# Kịch bản video demo (2 phút 30 giây)

Quay màn hình điện thoại thật, chèn chữ to, nhạc nền nhẹ. Không quay logo sàn.

| Thời gian | Hình | Lời / chữ trên màn |
|---|---|---|
| 0:00–0:15 | Ảnh bình luận "xin file tính phí" (che tên) | "Phí sàn lên 23–25% doanh thu. Người bán vẫn đi xin file Excel để biết mình lãi bao nhiêu." |
| 0:15–0:30 | Mở app, màn Chọn sàn → Shopee, Shop thường | "Lãi Thật: không cần đăng nhập, chọn sàn là dùng." |
| 0:30–0:55 | Tính lãi: ngành Sở thích & Sưu tầm, vốn 8.000đ, bán 17.000đ, gói 1.500đ | Thẻ kết quả: "505đ · Lãi mỏng 3,0% · Hòa vốn 16.340đ". "Sàn và thuế lấy 41% giá bán." |
| 0:55–1:15 | Chạm "Xem từng khoản phí", bấm (i) phí giao dịch, bật Voucher Xtra | "Mỗi khoản có cách tính và nguồn. Bật gói voucher thấy lãi giảm ngay." |
| 1:15–1:40 | Chuyển "Từ % lãi muốn có", chọn 20% | "Giá nên bán 22.900đ, lãi 5.018đ. Flash Sale giảm 30% là lỗ. Giá nhập tối đa 8.438đ." |
| 1:40–1:55 | So sánh sàn | "Cùng sản phẩm: TikTok Shop lãi 1.015đ, Shopee 505đ." |
| 1:55–2:15 | Danh mục: banner "2 sản phẩm chuyển sang lỗ", giá gợi ý | "Sàn đổi phí, app báo sản phẩm nào đang lỗ và nên bán giá nào." |
| 2:15–2:30 | Bảng đối chiếu 8 đơn thật (từ VALIDATION_REPORT) | "Công thức khớp 8/8 đơn Shopee thật. App được build bằng AI theo mẫu LLM Wiki." |
