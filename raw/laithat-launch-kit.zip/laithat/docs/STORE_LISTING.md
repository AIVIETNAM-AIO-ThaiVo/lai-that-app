# Google Play store listing (tiếng Việt)

## Thông tin chính

| Trường | Nội dung | Giới hạn |
|---|---|---|
| Tên app | Lãi Thật: Tính Phí Sàn TMĐT | 27/30 |
| Mô tả ngắn | Tính giá bán, phí sàn và lãi thật từng sản phẩm. Báo khi phí sàn đổi. | 72/80 |
| Danh mục | Kinh doanh (Business) | |
| Thẻ | Chọn các thẻ gần nhất trong Play Console (ví dụ: công cụ kinh doanh, máy tính) | |
| Email liên hệ | [EMAIL NHÓM] | |
| Chính sách quyền riêng tư | [URL GitHub Pages tới docs/privacy-policy.html] | |
| Có quảng cáo | Có | |
| Mua trong ứng dụng | Có: 49.000đ/tháng, 299.000đ/năm | |

Không dùng tên sàn trong tên app, biểu tượng, ảnh đồ họa. Tên sàn chỉ xuất hiện trong mô tả dài để nói app hỗ trợ sàn nào, kèm câu miễn trừ.

## Mô tả dài (dán nguyên văn, ~2.100/4.000 ký tự)

```
Bán 17.000đ có lãi không? Lãi Thật trả lời trong 10 giây.

Phí sàn TMĐT đã lên khoảng 23–25% doanh thu và đổi nhiều lần mỗi năm. Lãi Thật tính chính xác số tiền bạn thật sự giữ lại sau phí cố định theo ngành, phí xử lý giao dịch, phí hạ tầng, gói voucher, PiShip, thuế khấu trừ và chi phí của chính bạn.

TÍNH LÃI TỪ GIÁ BÁN
• Chọn ngành hàng, nhập giá vốn và giá bán: thấy ngay lãi mỗi đơn, % lãi và giá hòa vốn.
• Tính đúng mã giảm giá của shop và phí ship người mua trả, vì phí sàn được tính trên những con số này.
• Màu và chữ rõ ràng: Lãi, Lãi mỏng hay Lỗ.

TÍNH GIÁ TỪ % LÃI MUỐN CÓ
• Muốn lãi 20%? App ra giá nên bán, làm tròn thành giá đẹp và cho biết lãi thật ở giá đó.
• Bảng Flash Sale: giảm 10%, 20%, 30% thì còn lãi bao nhiêu.
• Giá nhập tối đa để trả giá với nhà cung cấp.

XEM TỪNG KHOẢN PHÍ
• Mỗi khoản phí có giải thích cách tính và ngày áp dụng.
• Bật/tắt Voucher Xtra, PiShip, phí hiển thị, thuế để thấy lãi thay đổi.
• Sửa được mọi con số nếu shop bạn có mức phí riêng.

SO SÁNH SÀN VÀ CHI PHÍ ẨN
• Cùng một sản phẩm, bán ở sàn nào lãi hơn.
• Tính cả đơn hoàn, quảng cáo (ROAS hòa vốn, tiền ads tối đa mỗi đơn) và affiliate.

DANH MỤC VÀ BÁO ĐỘNG ĐỔI PHÍ
• Lưu sản phẩm, xếp sản phẩm lãi thấp nhất lên đầu, kèm giá gợi ý.
• Khi sàn đổi biểu phí, app tính lại và báo sản phẩm nào vừa chuyển sang lỗ.

ĐÃ ĐỐI CHIẾU VỚI ĐƠN THẬT
Công thức được kiểm với chi tiết doanh thu của 8 đơn Shopee thật sau đợt đổi phí tháng 5/2026, lệch không quá 1đ.

DÙNG NGAY, KHÔNG CẦN TÀI KHOẢN
Không đăng nhập, không kết nối tài khoản bán hàng. Danh mục sản phẩm lưu trên máy bạn.

GÓI PRO
Danh mục không giới hạn, báo động từng sản phẩm khi phí đổi, Flash Sale, giá nhập tối đa, lãi dự kiến cả tháng, xuất danh mục, không quảng cáo. 49.000đ/tháng hoặc 299.000đ/năm, dùng thử 3 ngày, hủy bất cứ lúc nào trong Google Play.

Hỗ trợ: Shopee (shop thường), TikTok Shop, Lazada.

Lãi Thật là công cụ độc lập, không liên kết với Shopee, TikTok hay Lazada. Biểu phí dùng để tham khảo, ghi rõ ngày áp dụng trong app. Hãy đối chiếu với Kênh Người Bán của bạn trước khi quyết định.
```

## Ảnh chụp màn hình (chụp từ app thật, 1080×1920, chữ chú thích trên nền #F6F7F9)

1. "Bán 17.000đ có lãi không? Biết trong 10 giây" → màn Tính lãi, kết quả Lãi mỏng 505đ
2. "Muốn lãi 20%, bán bao nhiêu?" → màn Từ % lãi, giá nên bán 22.900đ
3. "Thấy từng khoản phí sàn lấy" → Chi tiết phí, "Sàn + thuế lấy 41%"
4. "Chạy Flash Sale có còn lãi?" → bảng giảm 10/20/30%
5. "Sàn đổi phí? App báo sản phẩm nào đang lỗ" → Danh mục + banner
6. "So lãi các sàn trên cùng sản phẩm" → So sánh sàn

Ảnh đồ họa (1024×500): nền #12161C, chữ trắng "Lãi Thật" + "505đ · Lãi mỏng 3,0%" màu #A16207. Không có logo sàn.

## Data safety (trả lời trong Play Console)

| Câu hỏi | Trả lời |
|---|---|
| App có thu thập hoặc chia sẻ dữ liệu người dùng? | Có |
| Mã thiết bị / quảng cáo (Device or other IDs) | Thu thập, chia sẻ với Google (AdMob, Firebase); mục đích: quảng cáo, phân tích |
| Tương tác trong app (App interactions) | Thu thập; mục đích: phân tích |
| Nhật ký sự cố, chẩn đoán | Thu thập; mục đích: phân tích, độ ổn định app |
| Lịch sử mua hàng | Thu thập (qua Google Play Billing); mục đích: chức năng app |
| Thông tin tài chính, vị trí, danh bạ, ảnh, tin nhắn | Không thu thập |
| Danh mục sản phẩm, giá vốn người dùng nhập | Chỉ lưu trên máy, không gửi đi → không khai là "thu thập" |
| Dữ liệu được mã hóa khi truyền | Có (HTTPS của Firebase/AdMob) |
| Người dùng yêu cầu xóa dữ liệu được không | Có: xóa app hoặc dùng nút "Xóa dữ liệu" trong Cài đặt; dữ liệu phân tích theo chính sách Google |

## Phân loại nội dung (IARC)

Không bạo lực, không nội dung người lớn, không cờ bạc, không chia sẻ vị trí, có quảng cáo, có mua trong app → dự kiến 3+ / Mọi lứa tuổi. Đối tượng mục tiêu: 18+ (không nhắm trẻ em; tránh chính sách Families).

## Khai báo khác

- App tài chính? Không cho vay, không tư vấn đầu tư; khai "công cụ tính toán kinh doanh".
- Quyền nhạy cảm: không có. `POST_NOTIFICATIONS` xin khi người dùng bật báo động.
- Quảng cáo: có, AdMob, có bảng đồng ý UMP.
