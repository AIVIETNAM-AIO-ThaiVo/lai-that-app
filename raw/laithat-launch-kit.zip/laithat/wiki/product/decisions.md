# Quyết định sản phẩm

| Ngày | Quyết định | Lý do |
|---|---|---|
| 2026-11-12 | Không đăng nhập, không API sàn, không quản lý đơn hàng | App là công cụ tính giá trước khi đăng bán; BigSeller (miễn phí < 1.500 đơn/tháng), Sapo, Nhanh đã làm phần sau bán |
| 2026-11-12 | Không khóa tính lãi, chi tiết phí, tính theo % lãi, so sánh sàn | Đối thủ trực tiếp Shopee Calc miễn phí; người dùng phải thấy giá trị trước paywall |
| 2026-11-12 | Pro bán: báo động từng sản phẩm, danh mục không giới hạn, Flash Sale, giá nhập tối đa, lãi tháng, xuất file, không quảng cáo | Đây là thứ tiết kiệm thời gian cho shop có nhiều sản phẩm |
| 2026-11-12 | Gộp tính xuôi và tính ngược vào một màn | Markup Margin (4,8★, 10N+ lượt cài) dùng mẫu "nhập 2 ô bất kỳ" |
| 2026-11-12 | Phí % tính trên giá sau mã giảm giá shop; phí giao dịch cộng ship người mua trả | 8/8 đơn Shopee thật |
| 2026-11-12 | PiShip, phí hiển thị, GTGT là công tắc | Chỉ một phần đơn thật có các khoản này |
| 2026-11-12 | TikTok/Lazada: cho sửa từng dòng, ghi "chưa đối chiếu đủ" | Mới có 1 đơn TikTok, 0 đơn Lazada |
| 2026-11-12 | Không dùng màu/logo sàn; sàn là chip chữ trung tính | Chính sách mạo danh của Google Play |
| 2026-11-12 | Không quảng cáo trên màn Tính lãi, không interstitial trong 2 phiên đầu | Đánh giá 1★ của app margin calculator vì quảng cáo chen ngang |
| 2026-11-12 | Báo trước 1 ngày khi hết dùng thử, hủy dễ | Đánh giá 1★ của TrueProfit/BeProfit vì trừ tiền bất ngờ |
